

const allProducts = (req,res)=>{
    res.send('allProducts')
}
const oneProduct = (req,res)=>{
    res.send('oneProduct')
}
const addProduct = (req,res)=>{
    res.send('addProduct')
}
const editProduct = (req,res)=>{
     res.send('editProduct')
}
const removeProduct = (req,res)=>{
    res.send('removeProduct')
}


module.exports = {
    allProducts,
    addProduct,
    oneProduct,
    editProduct,
    removeProduct
}