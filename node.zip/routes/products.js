const express = require('express')
const {
    allProducts,
    addProduct,
    oneProduct,
    editProduct,
    removeProduct
} = require('../controller/products')

const router = express.Router()

router.route('/').get(allProducts).post(addProduct)

router.route('/:id').get(oneProduct).patch(editProduct).delete(removeProduct)


module.exports = router