$(document).ready(function () {
  $(".side-bar").click(function () {
    $(".nav-con").show("slow");
  });
  $(".close").click(function () {
    $(".nav-con").hide("slow");
  });
});
